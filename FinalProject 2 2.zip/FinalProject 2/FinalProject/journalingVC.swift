//
//  journalingVC.swift
//  FinalProject
//
//  Created by Scholar on 8/4/21.
//

import UIKit

class journalingVC: UIViewController {
    @IBOutlet weak var entryOutlet: UITextView!
    @IBOutlet weak var entryOutputOutlet: UITextView!

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func submitTapped(_ sender: Any) {
        entryOutputOutlet.text = entryOutlet.text
    }



    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
