//
//  AffirmationsVC.swift
//  FinalProject
//
//  Created by Scholar on 8/6/21.
//

import UIKit

class AffirmationsVC: UIViewController {
    @IBOutlet weak var affirmationHereOutlet: UILabel!
    var affirmations = ["You are enough", "You are worth it", "You are loved", "You are appreciated", "You deserve everything good this world has to give", "You make the world a better place", "Your smile lights up cities", "You are talented", "You are trying your best and that is always enough", "You are inspiring"]
        
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func generateAffirmationTapped(_ sender: Any) {
        let randomIndex = Int.random(in: 0..<affirmations.count)
        let randomAffirmation = affirmations[randomIndex]
        affirmationHereOutlet.text = randomAffirmation
        
      //  if affirmationHereOutlet.text == randomAffirmation {
          //  affirmationHereOutlet.isHidden = false
      //  } else {
        //    affirmationHereOutlet.isHidden = true
       // }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
}

